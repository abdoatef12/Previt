package com.aplus.procam

import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.hypot

/**
 * Full photo editor: presets + manual sliders, live preview, full-quality export.
 * Everything is drawn in code so there is no extra layout file.
 */
class EditActivity : AppCompatActivity() {

    private data class P(
        var bri: Int = 0, var con: Int = 0, var sat: Int = 0,
        var warm: Int = 0, var tint: Int = 0, var fade: Int = 0,
        var shadows: Int = 0, var highlights: Int = 0,
        var sharp: Int = 0, var vig: Int = 0
    )

    private class Sl(
        val name: String, val min: Int, val max: Int,
        val get: (P) -> Int, val set: (P, Int) -> Unit
    )

    private val sliders = listOf(
        Sl("Brightness", -100, 100, { it.bri }, { p, v -> p.bri = v }),
        Sl("Contrast", -100, 100, { it.con }, { p, v -> p.con = v }),
        Sl("Saturation", -100, 100, { it.sat }, { p, v -> p.sat = v }),
        Sl("Warmth", -100, 100, { it.warm }, { p, v -> p.warm = v }),
        Sl("Tint", -100, 100, { it.tint }, { p, v -> p.tint = v }),
        Sl("Shadows", -100, 100, { it.shadows }, { p, v -> p.shadows = v }),
        Sl("Highlights", -100, 100, { it.highlights }, { p, v -> p.highlights = v }),
        Sl("Sharpness", 0, 100, { it.sharp }, { p, v -> p.sharp = v }),
        Sl("Fade", 0, 100, { it.fade }, { p, v -> p.fade = v }),
        Sl("Vignette", 0, 100, { it.vig }, { p, v -> p.vig = v })
    )

    private val presets = linkedMapOf(
        "Original" to P(),
        "Auto" to P(bri = 4, con = 14, sat = 16, shadows = 22, highlights = -18, sharp = 28),
        "Vivid" to P(con = 22, sat = 42, sharp = 22, shadows = 10),
        "Crisp" to P(con = 15, sharp = 70, shadows = 15, sat = 8),
        "Night" to P(bri = 14, shadows = 55, highlights = -20, sat = 12, sharp = 25),
        "Cinematic" to P(con = 25, sat = -14, warm = 16, tint = -6, vig = 32, fade = 12, shadows = 10),
        "Warm" to P(warm = 40, sat = 10, con = 6),
        "Cool" to P(warm = -40, sat = 6, con = 6),
        "Fade" to P(con = -14, fade = 38, sat = -10, bri = 5),
        "B&W" to P(sat = -100, con = 28, sharp = 22, vig = 16)
    )

    private var params = P()
    private var previewSrc: Bitmap? = null
    private var exportSrc: Bitmap? = null
    private var lastRendered: Bitmap? = null

    private lateinit var image: ImageView
    private lateinit var status: TextView
    private val bars = ArrayList<Triple<SeekBar, TextView, Sl>>()

    private val exec = Executors.newSingleThreadExecutor()
    private val version = AtomicInteger(0)
    private val accent = 0xFF4DA3FF.toInt()
    private val d by lazy { resources.displayMetrics.density }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) load(uri) else finish()
    }

    private fun dp(n: Int) = (n * d).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val u = intent.data
        if (u != null) load(u) else picker.launch("image/*")
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdownNow()
    }

    // ================= UI =================

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            fitsSystemWindows = true
        }

        // top bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        top.addView(btn("←") { finish() })
        top.addView(TextView(this).apply {
            text = "Edit"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            setPadding(dp(14), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(btn("Hold: Original").apply {
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> previewSrc?.let { image.setImageBitmap(it) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        (lastRendered ?: previewSrc)?.let { image.setImageBitmap(it) }
                }
                true
            }
        })
        top.addView(btn("Reset") { applyPreset(P()) }, lpMargin(dp(8)))
        top.addView(btn("💾 Save") { save() }.apply { setTextColor(accent) }, lpMargin(dp(8)))
        root.addView(top)

        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF000000.toInt())
        }
        root.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this).apply {
            setTextColor(0xFF9A9AA5.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
            text = "Loading…"
            setPadding(0, dp(4), 0, dp(4))
        }
        root.addView(status)

        // preset chips
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        for ((name, preset) in presets) {
            chips.addView(btn(name) { applyPreset(preset.copy()) }, lpMargin(dp(6)))
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        })

        // sliders
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        for (sl in sliders) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = sl.name
                setTextColor(0xFFB0B0B8.toInt())
                textSize = 13f
            }
            val value = TextView(this).apply {
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                gravity = Gravity.END
            }
            val bar = SeekBar(this).apply {
                max = sl.max - sl.min
                progressTintList = ColorStateList.valueOf(0xFFFFD60A.toInt())
                thumbTintList = ColorStateList.valueOf(0xFFFFD60A.toInt())
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        value.text = (p + sl.min).toString()
                        if (fromUser) {
                            sl.set(params, p + sl.min)
                            render()
                        }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            row.addView(label, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(bar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(value, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.WRAP_CONTENT))
            list.addView(row)
            bars += Triple(bar, value, sl)
        }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)))

        setContentView(root)
        syncSliders()
    }

    private fun lpMargin(m: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { marginStart = m }

    private fun btn(t: String, click: (() -> Unit)? = null) = TextView(this).apply {
        text = t
        setTextColor(0xFFFFFFFF.toInt())
        textSize = 13f
        setBackgroundResource(R.drawable.pill_bg)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        if (click != null) setOnClickListener { click() }
    }

    private fun syncSliders() {
        for ((bar, value, sl) in bars) {
            val v = sl.get(params)
            bar.progress = v - sl.min
            value.text = v.toString()
        }
    }

    private fun applyPreset(p: P) {
        params = p
        syncSliders()
        render()
    }

    // ================= Loading =================

    private fun load(uri: Uri) {
        status.text = "Loading…"
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > EXPORT_MAX) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw IllegalStateException("decode failed")
                val orient = contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
                bmp = orient(bmp, orient)
                val long = maxOf(bmp.width, bmp.height)
                val scale = if (long > PREVIEW_MAX) PREVIEW_MAX.toFloat() / long else 1f
                val prev = if (scale < 1f)
                    Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                else bmp
                exportSrc = bmp
                previewSrc = prev
                runOnUiThread {
                    status.text = "${bmp.width}×${bmp.height}"
                    image.setImageBitmap(prev)
                    render()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "مش قادر أفتح الصورة", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }.start()
    }

    private fun orient(src: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return src
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    // ================= Rendering =================

    /** Latest-wins background render of the preview. */
    private fun render() {
        val src = previewSrc ?: return
        val v = version.incrementAndGet()
        val p = params.copy()
        try {
            exec.execute {
                if (v != version.get()) return@execute
                val out = process(src, p)
                runOnUiThread {
                    if (v == version.get()) {
                        lastRendered = out
                        image.setImageBitmap(out)
                    }
                }
            }
        } catch (e: Exception) { /* activity closing */ }
    }

    private fun process(src: Bitmap, p: P): Bitmap = finishPass(colorPass(src, p), p)

    private fun colorPass(src: Bitmap, p: P): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)

        val cm = ColorMatrix()
        cm.setSaturation(1f + p.sat / 100f)

        val c = 1f + p.con / 100f * 0.6f
        val t = 128f * (1f - c) + p.bri * 1.2f
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )))

        if (p.warm != 0 || p.tint != 0) {
            val wv = p.warm / 100f
            val tv = p.tint / 100f
            cm.postConcat(ColorMatrix(floatArrayOf(
                1f + 0.18f * wv, 0f, 0f, 0f, 0f,
                0f, 1f - 0.12f * tv, 0f, 0f, 0f,
                0f, 0f, 1f - 0.18f * wv, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        if (p.fade != 0) {
            val f = p.fade / 100f * 0.25f
            val s = 1f - f
            val a = 255f * f * 0.5f
            cm.postConcat(ColorMatrix(floatArrayOf(
                s, 0f, 0f, 0f, a,
                0f, s, 0f, 0f, a,
                0f, 0f, s, 0f, a,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        cv.drawBitmap(src, 0f, 0f, paint)

        if (p.vig > 0) {
            val alpha = (p.vig / 100f * 215f).toInt().coerceIn(0, 255)
            val vp = Paint().apply {
                shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w.toDouble(), h.toDouble()).toFloat() / 2f,
                    intArrayOf(0x00000000, 0x00000000, alpha shl 24),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
            }
            cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vp)
        }
        return out
    }

    /** Shadows/highlights LUT + sharpening, streamed row by row so it also works at ~12 MP. */
    private fun finishPass(bm: Bitmap, p: P): Bitmap {
        val lutOn = p.shadows != 0 || p.highlights != 0
        val sh = p.sharp / 100f * 0.9f
        if (!lutOn && sh <= 0f) return bm

        val w = bm.width
        val h = bm.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        val lut = IntArray(256)
        val s = p.shadows / 100f
        val hl = p.highlights / 100f
        for (i in 0..255) {
            val x = i / 255f
            val y = x + 2f * s * x * (1f - x) * (1f - x) + 2f * hl * x * x * (1f - x)
            lut[i] = (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }

        var prev = IntArray(w)
        var cur = IntArray(w)
        var next = IntArray(w)
        val res = IntArray(w)
        bm.getPixels(cur, 0, w, 0, 0, w, 1)
        System.arraycopy(cur, 0, prev, 0, w)
        if (h > 1) bm.getPixels(next, 0, w, 0, 1, w, 1) else System.arraycopy(cur, 0, next, 0, w)

        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = cur[x]
                var r = (c shr 16) and 255
                var g = (c shr 8) and 255
                var b = c and 255
                if (sh > 0f) {
                    val l = cur[if (x > 0) x - 1 else x]
                    val rt = cur[if (x < w - 1) x + 1 else x]
                    val u = prev[x]
                    val dn = next[x]
                    r = (r + sh * (4 * r - ((l shr 16) and 255) - ((rt shr 16) and 255) -
                        ((u shr 16) and 255) - ((dn shr 16) and 255))).toInt().coerceIn(0, 255)
                    g = (g + sh * (4 * g - ((l shr 8) and 255) - ((rt shr 8) and 255) -
                        ((u shr 8) and 255) - ((dn shr 8) and 255))).toInt().coerceIn(0, 255)
                    b = (b + sh * (4 * b - (l and 255) - (rt and 255) -
                        (u and 255) - (dn and 255))).toInt().coerceIn(0, 255)
                }
                if (lutOn) { r = lut[r]; g = lut[g]; b = lut[b] }
                res[x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            out.setPixels(res, 0, w, 0, y, w, 1)
            val t = prev
            prev = cur
            cur = next
            next = t
            if (y + 2 < h) bm.getPixels(next, 0, w, 0, y + 2, w, 1)
            else System.arraycopy(cur, 0, next, 0, w)
        }
        bm.recycle()
        return out
    }

    // ================= Save =================

    private fun save() {
        val src = exportSrc ?: return
        val p = params.copy()
        status.text = "Saving…"
        Thread {
            try {
                val out = process(src, p)
                val name = "EDIT_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/APlusCam")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("insert failed")
                contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                runOnUiThread {
                    status.text = "${out.width}×${out.height}"
                    Toast.makeText(this, "اتحفظت ✔ (Pictures/APlusCam)", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = ""
                    Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    companion object {
        private const val EXPORT_MAX = 4096
        private const val PREVIEW_MAX = 1280
    }
}
