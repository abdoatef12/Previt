# A+ Cam v5 (Galaxy A16)
1. افتح المشروع في Android Studio واعمل Gradle sync، أو ارفعه على GitHub والـ Actions هيبني الـ APK.
2. Run على الموبايل أو Build > Build APK(s).

## الجديد في v2
- **مثبت بصري OIS** + مثبت إلكتروني EIS + الاتنين معًا (Settings > Quality > Stabilizer). التطبيق بيفحص العدسة ويعرض الدعم.
- **أقصى جودة صورة**: أعلى دقة للسنسور، JPEG 100%، تقليل ضوضاء/حدة/تصحيح ألوان/hot pixel/shading/tonemap بأعلى جودة (Quality Boost).
- **Contrast Curve** (Soft / Punch / Strong) داخل الكاميرا نفسها.
- **فريمات**: خيارات 24/30/60/90/120 fps بتظهر لو العدسة بتدعمها فعلاً + شاشة بتشتغل على أعلى معدل تحديث (90Hz).
- **Video Bitrate** (Auto / High / Max).
- **محرر صور كامل** (تبويب ✨ Edit أو ضغطة طويلة على 🖼): فلاتر جاهزة (Auto, Vivid, Crisp, Night, Cinematic, Warm, Cool, Fade, B&W) + سلايدرز: Brightness, Contrast, Saturation, Warmth, Tint, Shadows, Highlights, Sharpness, Fade, Vignette. معاينة فورية، ضغطة مطولة لمقارنة الأصل، وحفظ بجودة 100% في Pictures/APlusCam.

## ملاحظات
- 90fps فيديو بيعتمد على عتاد الكاميرا؛ لو A16 مش بتعلنه مش هيظهر في القائمة (الـ 90Hz للشاشة شغال دايمًا).
- RAW/DNG و4K مش متاحين على العتاد.

## أدوات على طريقة Blackmagic Camera (v3)
- **Analysis:** Histogram، Waveform، False Color، Zebra (مستوى 70–100%)، Focus Peaking (حساسية)، Level.
- **Guides:** Grid (Thirds / Center / Golden / Diagonals)، Frame Guides (2.39:1, 1.85:1, 16:9, 4:3, 1:1, 9:16)، Safe Zone.
- **Exposure/WB:** AE Lock، AWB Lock، ضغطة طويلة على الشاشة = AE/AF Lock، ISO / Shutter / Shutter Angle يدوي.
- **Anamorphic Desqueeze** (1.33x / 1.5x / 1.8x / 2x)، **Clean Feed** (إخفاء الواجهة).
- **Audio:** مقياس مستوى الصوت (dB) أثناء التسجيل.
- **Media:** Camera ID (A–D) وClip Counter تلقائي (A001, A002…)، عرض البطارية والمساحة والوقت المتبقي للتسجيل.
- **Zoom:** الضغط على رقم الزوم بيبدّل بين 0.6x (لو العدسة بتدعم) و1x و2x و5x.

غير متاح على أندرويد/CameraX: LUTs وLog وProRes/HEVC/10-bit وBlackmagic Cloud وTimecode وGenlock واختيار مصدر صوت خارجي.

## v4
- **Pro Look:** بعد كل صورة بيتحفظ نسخة PRO_ محسّنة تلقائيًا (Auto افتراضيًا) جنب الأصلية (Settings > Quality > Pro Look).
- فيديو بيبدأ بأعلى جودة تدعمها العدسة (4K لو متاحة).

## v5 — AI على الجهاز
- **AI Enhance:** بيتعرف على المشهد (أكل، سماء، طبيعة، مباني، حيوانات، ليل) والوجوه، ويحلل الإضاءة ويظبط كل صورة لوحدها + تنعيم بشرة خفيف. افتراضي بعد كل صورة، وزرار ✨ AI في المحرر. كله أوفلاين.
