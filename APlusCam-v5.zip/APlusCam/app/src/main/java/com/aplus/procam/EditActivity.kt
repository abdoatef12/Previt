package com.aplus.procam

import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.hypot

/**
 * Full photo editor: presets + manual sliders, live preview, full-quality export.
 * Everything is drawn in code so there is no extra layout file.
 */
private typealias P = EditParams

class EditActivity : AppCompatActivity() {

    private class Sl(
        val name: String, val min: Int, val max: Int,
        val get: (P) -> Int, val set: (P, Int) -> Unit
    )

    private val sliders = listOf(
        Sl("Brightness", -100, 100, { it.bri }, { p, v -> p.bri = v }),
        Sl("Contrast", -100, 100, { it.con }, { p, v -> p.con = v }),
        Sl("Saturation", -100, 100, { it.sat }, { p, v -> p.sat = v }),
        Sl("Warmth", -100, 100, { it.warm }, { p, v -> p.warm = v }),
        Sl("Tint", -100, 100, { it.tint }, { p, v -> p.tint = v }),
        Sl("Shadows", -100, 100, { it.shadows }, { p, v -> p.shadows = v }),
        Sl("Highlights", -100, 100, { it.highlights }, { p, v -> p.highlights = v }),
        Sl("Sharpness", 0, 100, { it.sharp }, { p, v -> p.sharp = v }),
        Sl("Fade", 0, 100, { it.fade }, { p, v -> p.fade = v }),
        Sl("Vignette", 0, 100, { it.vig }, { p, v -> p.vig = v })
    )

    private val presets = PhotoProcessor.presets

    private var params = P()
    private var previewSrc: Bitmap? = null
    private var exportSrc: Bitmap? = null
    private var lastRendered: Bitmap? = null
    private var aiResult: AiEnhancer.Result? = null

    private lateinit var image: ImageView
    private lateinit var status: TextView
    private val bars = ArrayList<Triple<SeekBar, TextView, Sl>>()

    private val exec = Executors.newSingleThreadExecutor()
    private val version = AtomicInteger(0)
    private val accent = 0xFF4DA3FF.toInt()
    private val d by lazy { resources.displayMetrics.density }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) load(uri) else finish()
    }

    private fun dp(n: Int) = (n * d).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val u = intent.data
        if (u != null) load(u) else picker.launch("image/*")
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdownNow()
    }

    // ================= UI =================

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            fitsSystemWindows = true
        }

        // top bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        top.addView(btn("←") { finish() })
        top.addView(TextView(this).apply {
            text = "Edit"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            setPadding(dp(14), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(btn("Hold: Original").apply {
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> previewSrc?.let { image.setImageBitmap(it) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        (lastRendered ?: previewSrc)?.let { image.setImageBitmap(it) }
                }
                true
            }
        })
        top.addView(btn("Reset") { applyPreset(P()) }, lpMargin(dp(8)))
        top.addView(btn("💾 Save") { save() }.apply { setTextColor(accent) }, lpMargin(dp(8)))
        root.addView(top)

        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF000000.toInt())
        }
        root.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this).apply {
            setTextColor(0xFF9A9AA5.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
            text = "Loading…"
            setPadding(0, dp(4), 0, dp(4))
        }
        root.addView(status)

        // preset chips
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        chips.addView(btn("✨ AI") { runAi() }.apply { setTextColor(0xFFFFD60A.toInt()) }, lpMargin(dp(6)))
        for ((name, preset) in presets) {
            chips.addView(btn(name) { applyPreset(preset.copy()) }, lpMargin(dp(6)))
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        })

        // sliders
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        for (sl in sliders) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = sl.name
                setTextColor(0xFFB0B0B8.toInt())
                textSize = 13f
            }
            val value = TextView(this).apply {
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                gravity = Gravity.END
            }
            val bar = SeekBar(this).apply {
                max = sl.max - sl.min
                progressTintList = ColorStateList.valueOf(0xFFFFD60A.toInt())
                thumbTintList = ColorStateList.valueOf(0xFFFFD60A.toInt())
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        value.text = (p + sl.min).toString()
                        if (fromUser) {
                            sl.set(params, p + sl.min)
                            render()
                        }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            row.addView(label, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(bar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(value, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.WRAP_CONTENT))
            list.addView(row)
            bars += Triple(bar, value, sl)
        }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)))

        setContentView(root)
        syncSliders()
    }

    private fun lpMargin(m: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { marginStart = m }

    private fun btn(t: String, click: (() -> Unit)? = null) = TextView(this).apply {
        text = t
        setTextColor(0xFFFFFFFF.toInt())
        textSize = 13f
        setBackgroundResource(R.drawable.pill_bg)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        if (click != null) setOnClickListener { click() }
    }

    private fun syncSliders() {
        for ((bar, value, sl) in bars) {
            val v = sl.get(params)
            bar.progress = v - sl.min
            value.text = v.toString()
        }
    }

    private fun applyPreset(p: P) {
        aiResult = null
        params = p
        syncSliders()
        render()
    }

    // ================= Loading =================

    private fun load(uri: Uri) {
        status.text = "Loading…"
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > EXPORT_MAX) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw IllegalStateException("decode failed")
                val orient = contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
                bmp = PhotoProcessor.orient(bmp, orient)
                val long = maxOf(bmp.width, bmp.height)
                val scale = if (long > PREVIEW_MAX) PREVIEW_MAX.toFloat() / long else 1f
                val prev = if (scale < 1f)
                    Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                else bmp
                exportSrc = bmp
                previewSrc = prev
                runOnUiThread {
                    status.text = "${bmp.width}×${bmp.height}"
                    image.setImageBitmap(prev)
                    render()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "مش قادر أفتح الصورة", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }.start()
    }

    // ================= Rendering =================

    /** Latest-wins background render of the preview. */
    private fun render() {
        val src = previewSrc ?: return
        val v = version.incrementAndGet()
        val p = params.copy()
        try {
            exec.execute {
                if (v != version.get()) return@execute
                val out = process(src, p)
                runOnUiThread {
                    if (v == version.get()) {
                        lastRendered = out
                        image.setImageBitmap(out)
                    }
                }
            }
        } catch (e: Exception) { /* activity closing */ }
    }

    private fun process(src: Bitmap, p: P): Bitmap {
        val out = PhotoProcessor.process(src, p)
        val ai = aiResult
        val ps = previewSrc
        if (ai != null && ps != null && ai.faces.isNotEmpty())
            AiEnhancer.smoothFaces(out, ai.faces, src.width.toFloat() / ps.width)
        return out
    }

    /** On-device AI: analyses scene, faces and exposure, then sets the sliders for this photo. */
    private fun runAi() {
        val src = previewSrc ?: return
        status.text = "AI analyzing…"
        Thread {
            val r = try { AiEnhancer.analyze(src) } catch (e: Throwable) { null }
            runOnUiThread {
                if (r == null) {
                    status.text = "AI مش متاح دلوقتي"
                } else {
                    aiResult = r
                    params = r.params.copy()
                    syncSliders()
                    render()
                    status.text = "AI: " + r.tags.joinToString(" · ").ifEmpty { "auto" }
                }
            }
        }.start()
    }

    // ================= Save =================

    private fun save() {
        val src = exportSrc ?: return
        val p = params.copy()
        status.text = "Saving…"
        Thread {
            try {
                val out = process(src, p)
                val name = "EDIT_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/APlusCam")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("insert failed")
                contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                runOnUiThread {
                    status.text = "${out.width}×${out.height}"
                    Toast.makeText(this, "اتحفظت ✔ (Pictures/APlusCam)", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = ""
                    Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    companion object {
        private const val EXPORT_MAX = 4096
        private const val PREVIEW_MAX = 1280
    }
}
