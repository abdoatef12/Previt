package com.aplus.procam

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

class AnalysisOverlay @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var showHist = false
    var showWave = false
    var showLevel = false
    var roll = 0f
        set(v) { field = v; if (showLevel) invalidate() }

    private var hist: IntArray? = null
    private var wave: IntArray? = null
    private var bmp: Bitmap? = null
    private val d = resources.displayMetrics.density
    private val bg = Paint().apply { color = 0x88000000.toInt() }
    private val bar = Paint().apply { color = 0xFFFFFFFF.toInt() }
    private val wavePaint = Paint().apply { color = 0xFF30FF70.toInt() }
    private val line = Paint().apply { strokeWidth = 3f * d; isAntiAlias = true }

    companion object {
        const val WC = 96   // waveform columns
        const val WL = 48   // waveform levels
    }

    fun setData(h: IntArray?, pix: IntArray?, gw: Int, gh: Int, wv: IntArray? = null) {
        hist = h
        wave = wv
        bmp = if (pix == null) null else {
            var bm = bmp
            if (bm == null || bm.width != gw || bm.height != gh)
                bm = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
            bm.setPixels(pix, 0, gw, 0, 0, gw, gh)
            bm
        }
        invalidate()
    }

    fun clear() { hist = null; wave = null; bmp = null; invalidate() }

    override fun onDraw(cv: Canvas) {
        bmp?.let { cv.drawBitmap(it, null, Rect(0, 0, width, height), null) }
        val h = hist
        if (showHist && h != null) {
            val left = 16 * d
            val top = 88 * d
            val bw = 2 * d
            val hh = 48 * d
            cv.drawRect(left - 6 * d, top - 6 * d, left + 64 * bw + 6 * d, top + hh + 6 * d, bg)
            val mx = (h.maxOrNull() ?: 1).coerceAtLeast(1)
            for (i in 0 until 64) {
                val bh = hh * h[i] / mx
                cv.drawRect(left + i * bw, top + hh - bh, left + (i + 1) * bw - 1f, top + hh, bar)
            }
        }
        val wv = wave
        if (showWave && wv != null) {
            val left = 16 * d
            val top = 150 * d
            val cw = 1.33f * d
            val total = 64 * d
            val ch = total / WL
            cv.drawRect(left - 6 * d, top - 6 * d, left + WC * cw + 6 * d, top + total + 6 * d, bg)
            val mx = (wv.maxOrNull() ?: 1).coerceAtLeast(1)
            for (gx in 0 until WC) for (l in 0 until WL) {
                val n = wv[gx * WL + l]
                if (n <= 0) continue
                wavePaint.alpha = (255f * n / (mx * 0.25f)).coerceIn(70f, 255f).toInt()
                val x = left + gx * cw
                val y = top + total - (l + 1) * ch
                cv.drawRect(x, y, x + cw, y + ch, wavePaint)
            }
        }
        if (showLevel) {
            val level = abs(roll) < 1.5f
            line.color = if (level) 0xFFFFD60A.toInt() else 0xFFFFFFFF.toInt()
            cv.save()
            cv.translate(width / 2f, height / 2f)
            cv.rotate(roll)
            cv.drawLine(-70 * d, 0f, 70 * d, 0f, line)
            cv.restore()
        }
    }
}
