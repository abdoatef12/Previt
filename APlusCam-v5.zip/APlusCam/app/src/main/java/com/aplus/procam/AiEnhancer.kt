package com.aplus.procam

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions

/**
 * On-device AI enhancement (nothing leaves the phone):
 *  - ML Kit image labeling recognises the scene (food, sky, nature, city, pet, night...)
 *  - ML Kit face detection finds portraits (face exposure + soft skin)
 *  - histogram analysis fixes dark / flat / blown-out photos
 * The result is a set of edit parameters tuned to THIS photo.
 */
object AiEnhancer {

    class Result(val params: EditParams, val faces: List<Rect>, val tags: List<String>)

    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }
    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }

    /** Must be called off the main thread. Face rects are in the coordinates of [src]. */
    fun analyze(src: Bitmap): Result {
        val long = maxOf(src.width, src.height)
        val k = if (long > 640) 640f / long else 1f
        val small = if (k < 1f)
            Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
        else src
        val w = small.width
        val h = small.height
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)

        // ---- histogram statistics
        val hist = IntArray(256)
        var sum = 0L
        for (c in px) {
            val l = (299 * ((c shr 16) and 255) + 587 * ((c shr 8) and 255) + 114 * (c and 255)) / 1000
            hist[l]++
            sum += l
        }
        val n = px.size.toFloat()
        val mean = sum / n
        var acc = 0
        var p5 = 0
        var p95 = 255
        var got5 = false
        for (i in 0..255) {
            acc += hist[i]
            if (!got5 && acc >= n * 0.05f) { p5 = i; got5 = true }
            if (acc >= n * 0.95f) { p95 = i; break }
        }
        var clipped = 0
        for (i in 250..255) clipped += hist[i]
        var crushed = 0
        for (i in 0..5) crushed += hist[i]
        val clipFrac = clipped / n
        val crushFrac = crushed / n

        // ---- AI: scene + faces (fall back to stats-only if the model is unavailable)
        val image = InputImage.fromBitmap(small, 0)
        val labels: List<ImageLabel> = try {
            Tasks.await(labeler.process(image))
        } catch (e: Exception) { emptyList() }
        val faceList: List<Face> = try {
            Tasks.await(detector.process(image))
        } catch (e: Exception) { emptyList() }

        var bri = 0; var con = 0; var sat = 8; var warm = 0
        var shadows = 0; var hl = 0; var sharp = 22; var vig = 0

        // exposure
        if (mean < 95) {
            bri += ((95 - mean) * 0.35f).toInt().coerceAtMost(28)
            shadows += ((95 - mean) * 0.9f).toInt().coerceAtMost(60)
        } else if (mean > 175) {
            bri -= ((mean - 175) * 0.3f).toInt().coerceAtMost(15)
        }
        if (clipFrac > 0.02f) hl -= (clipFrac * 800).toInt().coerceIn(15, 45)
        if (crushFrac > 0.15f) shadows += 15
        val range = p95 - p5
        if (range < 180) con += ((180 - range) * 0.2f).toInt().coerceAtMost(26)

        // scene
        val tags = ArrayList<String>()
        for (lb in labels.filter { it.confidence >= 0.55f }.take(3)) tags += lb.text
        val names = labels.filter { it.confidence >= 0.55f }.map { it.text.lowercase() }
        fun has(vararg keys: String) = names.any { n2 -> keys.any { n2.contains(it) } }
        when {
            has("food", "dish", "cuisine", "meal", "dessert", "fruit", "cake", "pizza", "coffee") -> {
                sat += 18; warm += 10; sharp += 10; con += 4
            }
            has("sky", "cloud", "sunset", "sunrise", "sea", "beach", "ocean", "mountain", "lake", "water") -> {
                sat += 20; con += 8; hl -= 8; sharp += 6
            }
            has("plant", "flower", "tree", "grass", "leaf", "garden", "nature", "forest") -> {
                sat += 22; con += 6; sharp += 8
            }
            has("building", "architecture", "city", "skyscraper", "tower", "street", "house", "bridge") -> {
                sharp += 28; con += 10; sat += 4
            }
            has("dog", "cat", "pet", "animal", "bird") -> {
                sharp += 14; sat += 8
            }
            has("night", "neon", "fireworks", "light") -> {
                shadows += 10; sat += 6; vig += 8
            }
            has("snow") -> { bri -= 6; con += 6 }
        }

        // faces: protect skin, lift dark faces, no over-sharpening
        val faces = ArrayList<Rect>()
        if (faceList.isNotEmpty()) {
            var fSum = 0L
            var fCnt = 0
            for (f in faceList) {
                val r = f.boundingBox
                val l = r.left.coerceIn(0, w - 1); val rt = r.right.coerceIn(l + 1, w)
                val t = r.top.coerceIn(0, h - 1); val bt = r.bottom.coerceIn(t + 1, h)
                for (y in t until bt step 2) for (x in l until rt step 2) {
                    val c = px[y * w + x]
                    fSum += (299 * ((c shr 16) and 255) + 587 * ((c shr 8) and 255) + 114 * (c and 255)) / 1000
                    fCnt++
                }
                // back to full-size coordinates
                faces += Rect(
                    (r.left / k).toInt(), (r.top / k).toInt(),
                    (r.right / k).toInt(), (r.bottom / k).toInt()
                )
            }
            val fMean = if (fCnt > 0) fSum / fCnt.toFloat() else 128f
            if (fMean < 105f) { bri += 8; shadows += 12 }
            sharp = 10
            warm += 4
            sat = (sat - 4).coerceAtLeast(4)
            tags += "Portrait"
        }

        val p = EditParams(
            bri = bri.coerceIn(-100, 100), con = con.coerceIn(-100, 100), sat = sat.coerceIn(-100, 100),
            warm = warm.coerceIn(-100, 100), shadows = shadows.coerceIn(-100, 100),
            highlights = hl.coerceIn(-100, 100), sharp = sharp.coerceIn(0, 100), vig = vig.coerceIn(0, 100)
        )
        return Result(p, faces, tags)
    }

    /** Full AI pass: tuned colour/tone edit + gentle soft-skin on detected faces. */
    fun apply(src: Bitmap, r: Result): Bitmap {
        val out = PhotoProcessor.process(src, r.params)
        if (r.faces.isNotEmpty()) smoothFaces(out, r.faces, 1f)
        return out
    }

    /** Soft-skin: blends a blurred copy of each face (oval) at low strength. [scale] maps rect coords to [out]. */
    fun smoothFaces(out: Bitmap, faces: List<Rect>, scale: Float) {
        val cv = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 80 }
        for (r in faces) {
            val padW = ((r.width()) * scale * 0.05f).toInt()
            val padH = ((r.height()) * scale * 0.05f).toInt()
            val l = (r.left * scale).toInt() - padW
            val t = (r.top * scale).toInt() - padH
            val rr = (r.right * scale).toInt() + padW
            val bb = (r.bottom * scale).toInt() + padH
            val x0 = l.coerceIn(0, out.width - 2)
            val y0 = t.coerceIn(0, out.height - 2)
            val x1 = rr.coerceIn(x0 + 1, out.width)
            val y1 = bb.coerceIn(y0 + 1, out.height)
            val fw = x1 - x0
            val fh = y1 - y0
            if (fw < 16 || fh < 16) continue
            val crop = Bitmap.createBitmap(out, x0, y0, fw, fh)
            val tiny = Bitmap.createScaledBitmap(crop, maxOf(fw / 5, 4), maxOf(fh / 5, 4), true)
            val blur = Bitmap.createScaledBitmap(tiny, fw, fh, true)
            val path = Path().apply {
                addOval(RectF(x0.toFloat(), y0.toFloat(), x1.toFloat(), y1.toFloat()), Path.Direction.CW)
            }
            cv.save()
            cv.clipPath(path)
            cv.drawBitmap(blur, x0.toFloat(), y0.toFloat(), paint)
            cv.restore()
        }
    }
}
