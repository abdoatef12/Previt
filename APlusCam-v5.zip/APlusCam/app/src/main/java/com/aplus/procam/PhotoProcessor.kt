package com.aplus.procam

import android.content.ContentResolver
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import kotlin.math.hypot

data class EditParams(
    var bri: Int = 0, var con: Int = 0, var sat: Int = 0,
    var warm: Int = 0, var tint: Int = 0, var fade: Int = 0,
    var shadows: Int = 0, var highlights: Int = 0,
    var sharp: Int = 0, var vig: Int = 0
)

/** Shared image pipeline: used by the editor and by the automatic "Pro Look" after capture. */
object PhotoProcessor {

    val presets = linkedMapOf(
        "Original" to EditParams(),
        "Auto" to EditParams(bri = 4, con = 14, sat = 16, shadows = 22, highlights = -18, sharp = 28),
        "Vivid" to EditParams(con = 22, sat = 42, sharp = 22, shadows = 10),
        "Crisp" to EditParams(con = 15, sharp = 70, shadows = 15, sat = 8),
        "Night" to EditParams(bri = 14, shadows = 55, highlights = -20, sat = 12, sharp = 25),
        "Cinematic" to EditParams(con = 25, sat = -14, warm = 16, tint = -6, vig = 32, fade = 12, shadows = 10),
        "Warm" to EditParams(warm = 40, sat = 10, con = 6),
        "Cool" to EditParams(warm = -40, sat = 6, con = 6),
        "Fade" to EditParams(con = -14, fade = 38, sat = -10, bri = 5),
        "B&W" to EditParams(sat = -100, con = 28, sharp = 22, vig = 16)
    )


    fun process(src: Bitmap, p: EditParams): Bitmap = finishPass(colorPass(src, p), p)

    /** Decode with EXIF rotation applied, down-sampled so the long side is <= maxSide. */
    fun loadOriented(cr: ContentResolver, uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val o = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        return orient(bmp, o)
    }

    fun saveJpeg(cr: ContentResolver, bmp: Bitmap, name: String): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/APlusCam")
        }
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        cr.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
        return uri
    }

    fun orient(src: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return src
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun colorPass(src: Bitmap, p: EditParams): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)

        val cm = ColorMatrix()
        cm.setSaturation(1f + p.sat / 100f)

        val c = 1f + p.con / 100f * 0.6f
        val t = 128f * (1f - c) + p.bri * 1.2f
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )))

        if (p.warm != 0 || p.tint != 0) {
            val wv = p.warm / 100f
            val tv = p.tint / 100f
            cm.postConcat(ColorMatrix(floatArrayOf(
                1f + 0.18f * wv, 0f, 0f, 0f, 0f,
                0f, 1f - 0.12f * tv, 0f, 0f, 0f,
                0f, 0f, 1f - 0.18f * wv, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        if (p.fade != 0) {
            val f = p.fade / 100f * 0.25f
            val s = 1f - f
            val a = 255f * f * 0.5f
            cm.postConcat(ColorMatrix(floatArrayOf(
                s, 0f, 0f, 0f, a,
                0f, s, 0f, 0f, a,
                0f, 0f, s, 0f, a,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        cv.drawBitmap(src, 0f, 0f, paint)

        if (p.vig > 0) {
            val alpha = (p.vig / 100f * 215f).toInt().coerceIn(0, 255)
            val vp = Paint().apply {
                shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w.toDouble(), h.toDouble()).toFloat() / 2f,
                    intArrayOf(0x00000000, 0x00000000, alpha shl 24),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
            }
            cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vp)
        }
        return out
    }

    /** Shadows/highlights LUT + sharpening, streamed row by row so it also works at ~12 MP. */
    private fun finishPass(bm: Bitmap, p: EditParams): Bitmap {
        val lutOn = p.shadows != 0 || p.highlights != 0
        val sh = p.sharp / 100f * 0.9f
        if (!lutOn && sh <= 0f) return bm

        val w = bm.width
        val h = bm.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        val lut = IntArray(256)
        val s = p.shadows / 100f
        val hl = p.highlights / 100f
        for (i in 0..255) {
            val x = i / 255f
            val y = x + 2f * s * x * (1f - x) * (1f - x) + 2f * hl * x * x * (1f - x)
            lut[i] = (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }

        var prev = IntArray(w)
        var cur = IntArray(w)
        var next = IntArray(w)
        val res = IntArray(w)
        bm.getPixels(cur, 0, w, 0, 0, w, 1)
        System.arraycopy(cur, 0, prev, 0, w)
        if (h > 1) bm.getPixels(next, 0, w, 0, 1, w, 1) else System.arraycopy(cur, 0, next, 0, w)

        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = cur[x]
                var r = (c shr 16) and 255
                var g = (c shr 8) and 255
                var b = c and 255
                if (sh > 0f) {
                    val l = cur[if (x > 0) x - 1 else x]
                    val rt = cur[if (x < w - 1) x + 1 else x]
                    val u = prev[x]
                    val dn = next[x]
                    r = (r + sh * (4 * r - ((l shr 16) and 255) - ((rt shr 16) and 255) -
                        ((u shr 16) and 255) - ((dn shr 16) and 255))).toInt().coerceIn(0, 255)
                    g = (g + sh * (4 * g - ((l shr 8) and 255) - ((rt shr 8) and 255) -
                        ((u shr 8) and 255) - ((dn shr 8) and 255))).toInt().coerceIn(0, 255)
                    b = (b + sh * (4 * b - (l and 255) - (rt and 255) -
                        (u and 255) - (dn and 255))).toInt().coerceIn(0, 255)
                }
                if (lutOn) { r = lut[r]; g = lut[g]; b = lut[b] }
                res[x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            out.setPixels(res, 0, w, 0, y, w, 1)
            val t = prev
            prev = cur
            cur = next
            next = t
            if (y + 2 < h) bm.getPixels(next, 0, w, 0, y + 2, w, 1)
            else System.arraycopy(cur, 0, next, 0, w)
        }
        bm.recycle()
        return out
    }

}
