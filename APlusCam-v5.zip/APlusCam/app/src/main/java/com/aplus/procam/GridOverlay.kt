package com.aplus.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Grids, frame guides (cinema aspect ratios) and safe zones. */
class GridOverlay @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var gridType = 0          // 0 off, 1 thirds, 2 center cross, 3 golden ratio, 4 diagonals
        set(v) { field = v; invalidate() }
    var guideIdx = 0
        set(v) { field = v; invalidate() }
    var safeZone = false
        set(v) { field = v; invalidate() }

    private val line = Paint().apply { color = 0x88FFFFFF.toInt(); strokeWidth = 2f }
    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val edge = Paint().apply {
        color = 0xFFFFD60A.toInt(); strokeWidth = 3f; style = Paint.Style.STROKE
    }
    private val safe = Paint().apply {
        color = 0x99FFFFFF.toInt(); strokeWidth = 2f; style = Paint.Style.STROKE
    }

    companion object {
        val guideRatios = listOf(0f, 2.39f, 1.85f, 16f / 9f, 4f / 3f, 1f, 9f / 16f)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        when (gridType) {
            1 -> for (i in 1..2) {
                canvas.drawLine(w * i / 3, 0f, w * i / 3, h, line)
                canvas.drawLine(0f, h * i / 3, w, h * i / 3, line)
            }
            2 -> {
                canvas.drawLine(w / 2, 0f, w / 2, h, line)
                canvas.drawLine(0f, h / 2, w, h / 2, line)
                canvas.drawCircle(w / 2, h / 2, 24f, line)
            }
            3 -> for (f in listOf(0.382f, 0.618f)) {
                canvas.drawLine(w * f, 0f, w * f, h, line)
                canvas.drawLine(0f, h * f, w, h * f, line)
            }
            4 -> {
                canvas.drawLine(0f, 0f, w, h, line)
                canvas.drawLine(w, 0f, 0f, h, line)
                canvas.drawLine(w / 2, 0f, w / 2, h, line)
                canvas.drawLine(0f, h / 2, w, h / 2, line)
            }
        }

        val r = guideRatios.getOrElse(guideIdx) { 0f }
        if (r > 0f) {
            val gw: Float
            val gh: Float
            if (w / h > r) { gh = h; gw = h * r } else { gw = w; gh = w / r }
            val l = (w - gw) / 2
            val t = (h - gh) / 2
            canvas.drawRect(0f, 0f, w, t, dim)
            canvas.drawRect(0f, t + gh, w, h, dim)
            canvas.drawRect(0f, t, l, t + gh, dim)
            canvas.drawRect(l + gw, t, w, t + gh, dim)
            canvas.drawRect(l, t, l + gw, t + gh, edge)
        }

        if (safeZone) {
            for (k in listOf(0.90f, 0.80f)) {
                canvas.drawRect(w * (1 - k) / 2, h * (1 - k) / 2, w * (1 + k) / 2, h * (1 + k) / 2, safe)
            }
        }
    }
}
