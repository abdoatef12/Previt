# A+ Cam (Galaxy A16)
1. Install Android Studio (latest) and open the APlusCam folder. Let Gradle sync.
2. Enable Developer options + USB debugging on the phone, connect it, press Run.
3. Or: Build > Build APK(s), then copy app-debug.apk to the phone.

Modes: PHOTO, VIDEO (1080p max on A16), PRO (manual ISO + shutter, if the lens reports support).
Controls: tap = focus, pinch = zoom, EV slider, flash/torch, grid, flip camera.
Saved to Pictures/APlusCam and Movies/APlusCam.

New: timer (3/10s), 4:3/16:9, Night/HDR/Portrait/Face (device extensions if available), filters, white balance presets,
manual focus (PRO), 1x/2x/5x zoom, video stabilization, volume-key shutter, gallery button, haptics.

Pro tools: live histogram, zebra (clipping), focus peaking, level/horizon, mic on/off.
Not possible on Galaxy A16 hardware: RAW/DNG, 4K video, 60fps, 8K.
