package com.aplus.procam

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.camera.core.ImageAnalysis
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.atan2
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.WindowManager
import androidx.camera.core.AspectRatio
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.provider.MediaStore
import android.util.Range
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.aplus.procam.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToInt

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity(), SensorEventListener {

    private enum class Mode { PHOTO, VIDEO, PRO }

    private lateinit var b: ActivityMainBinding
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var lens = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var flash = ImageCapture.FLASH_MODE_OFF
    private var torch = false

    private var showHist = false
    private var showZebra = false
    private var showPeak = false
    private var showLevel = false
    private var audioOn = true
    private val analysisExec = Executors.newSingleThreadExecutor()
    private var extMgr: ExtensionsManager? = null
    private var ratio169 = false
    private var timerSec = 0
    private var zoomIdx = 0
    private var extIdx = 0
    private var fxIdx = 0
    private var wbIdx = 0
    private var stab = false
    private var lastUri: Uri? = null
    private var minFocus = 0f
    private var availFx: IntArray? = null
    private var availWb: IntArray? = null

    private val zoomSteps = listOf(1f, 2f, 5f)
    private val extModes = listOf(ExtensionMode.NONE, ExtensionMode.AUTO, ExtensionMode.NIGHT,
        ExtensionMode.HDR, ExtensionMode.BOKEH, ExtensionMode.FACE_RETOUCH)
    private val extNames = listOf("Off", "Auto", "Night", "HDR", "Portrait", "Face")
    private val fxModes = listOf(0, 1, 2, 4, 5, 8)
    private val fxNames = listOf("None", "Mono", "Negative", "Sepia", "Poster", "Aqua")
    private val wbModes = listOf(1, 5, 6, 2, 3)
    private val wbNames = listOf("Auto", "Daylight", "Cloudy", "Tungsten", "Fluor")

    private var isoRange: Range<Int>? = null
    private var expRange: Range<Long>? = null

    private val main by lazy { ContextCompat.getMainExecutor(this) }
    private val accent = 0xFFFFD60A.toInt()

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera()
        else {
            Toast.makeText(this, "محتاج إذن الكاميرا", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setupTouch()
        setupChips()
        setupButtons()
        setupSliders()
        updateTabs()

        if (granted(Manifest.permission.CAMERA)) startCamera()
        else permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ---------- Camera ----------

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            provider = p
            val ef = ExtensionsManager.getInstanceAsync(this, p)
            ef.addListener({
                extMgr = ef.get()
                bind()
            }, main)
        }, main)
    }

    private fun bind() {
        val p = provider ?: return
        p.unbindAll()

        val base = CameraSelector.Builder().requireLensFacing(lens).build()
        val extMode = extModes[extIdx]
        val selector = if (mode == Mode.PHOTO && extMode != ExtensionMode.NONE &&
            extMgr?.isExtensionAvailable(base, extMode) == true
        ) extMgr!!.getExtensionEnabledCameraSelector(base, extMode) else base
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(
            AspectRatioStrategy(
                if (ratio169 || mode == Mode.VIDEO) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3,
                AspectRatioStrategy.FALLBACK_RULE_AUTO
            )
        ).build()
        val preview = Preview.Builder().setResolutionSelector(rs).build().also { it.setSurfaceProvider(b.preview.surfaceProvider) }
        val cases = mutableListOf<UseCase>(preview)

        if (mode == Mode.VIDEO) {
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.FHD, Quality.HD, Quality.SD),
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                ).build()
            videoCapture = VideoCapture.Builder(recorder).setVideoStabilizationEnabled(stab).build()
            imageCapture = null
            cases += videoCapture!!
        } else {
            imageCapture = ImageCapture.Builder()
                .setResolutionSelector(rs)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flash)
                .build()
            videoCapture = null
            cases += imageCapture!!
        }

        val anyTool = showHist || showZebra || showPeak
        if (anyTool && selector === base) {
            cases += ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build().also { it.setAnalyzer(analysisExec, analyzer) }
        }

        camera = try {
            p.bindToLifecycle(this, selector, *cases.toTypedArray())
        } catch (e: Exception) {
            if (anyTool && selector === base) {
                showHist = false; showZebra = false; showPeak = false
                updateChips()
                Toast.makeText(this, "الأدوات دي مش مدعومة هنا", Toast.LENGTH_SHORT).show()
                bind()
            } else if (extIdx != 0) {
                extIdx = 0
                updateChips()
                bind()
            } else Toast.makeText(this, "مش قادر أفتح الكاميرا: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        val cam = camera!!
        val info2 = Camera2CameraInfo.from(cam.cameraInfo)
        isoRange = info2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        expRange = info2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)

        minFocus = info2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        availFx = info2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS)
        availWb = info2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)
        cam.cameraInfo.zoomState.observe(this) { z ->
            b.zoomLabel.text = String.format(Locale.US, "%.1fx", z.zoomRatio)
        }

        if (mode == Mode.PRO && (isoRange == null || expRange == null)) {
            Toast.makeText(this, "التحكم اليدوي مش مدعوم على العدسة دي", Toast.LENGTH_LONG).show()
            mode = Mode.PHOTO
            updateTabs()
            bind()
            return
        }

        updateChips()
        if (!anyTool) b.overlay.clear()
        refreshPanel()
        applyManual()
        if (mode == Mode.VIDEO) cam.cameraControl.enableTorch(torch)
    }

    // ---------- Pro controls ----------

    private fun isoValue(): Int {
        val r = isoRange ?: return 100
        val lo = r.lower.toDouble()
        val hi = minOf(r.upper, 3200).toDouble()
        return (lo * (hi / lo).pow(b.isoBar.progress / 100.0)).roundToInt()
    }

    private fun shutterNs(): Long {
        val r = expRange ?: return 10_000_000L
        val lo = maxOf(r.lower, 250_000L).toDouble()          // 1/4000s
        val hi = minOf(r.upper, 250_000_000L).toDouble()      // 1/4s
        return (lo * (hi / lo).pow(b.ssBar.progress / 100.0)).toLong()
    }

    private fun shutterText(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/${(1 / s).roundToInt()}"
    }

    private fun applyManual() {
        val cam = camera ?: return
        val ctl = Camera2CameraControl.from(cam.cameraControl)
        val o = CaptureRequestOptions.Builder()
        if (fxIdx != 0) o.setCaptureRequestOption(CaptureRequest.CONTROL_EFFECT_MODE, fxModes[fxIdx])
        if (wbIdx != 0) o.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, wbModes[wbIdx])
        if (mode == Mode.PRO) {
            val iso = isoValue()
            val ns = shutterNs()
            o.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            o.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            o.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
            val fp = b.focusBar.progress
            if (fp > 0 && minFocus > 0f) {
                o.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                o.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * fp / 100f)
            }
            b.focusVal.text = if (fp == 0) "AF" else "$fp%"
            b.isoVal.text = iso.toString()
            b.ssVal.text = shutterText(ns)
            b.info.text = "ISO $iso · ${shutterText(ns)}"
        }
        ctl.setCaptureRequestOptions(o.build())
    }

    private fun refreshPanel() {
        val pro = mode == Mode.PRO
        val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange
        val evSupported = r != null && r.upper != r.lower
        b.evRow.visibility = if (!pro && evSupported) View.VISIBLE else View.GONE
        b.isoRow.visibility = if (pro) View.VISIBLE else View.GONE
        b.ssRow.visibility = if (pro) View.VISIBLE else View.GONE
        b.focusRow.visibility = if (pro && minFocus > 0f) View.VISIBLE else View.GONE
        b.panel.visibility = if (b.evRow.visibility == View.VISIBLE || pro) View.VISIBLE else View.GONE
        if (!pro) b.info.text = ""
        b.evBar.progress = 50
        b.evVal.text = "0.0"
    }

    private fun setupSliders() {
        b.evBar.onChange {
            val cam = camera ?: return@onChange
            val r = cam.cameraInfo.exposureState.exposureCompensationRange
            val idx = r.lower + ((r.upper - r.lower) * b.evBar.progress / 100f).roundToInt()
            cam.cameraControl.setExposureCompensationIndex(idx)
            val step = cam.cameraInfo.exposureState.exposureCompensationStep.toFloat()
            b.evVal.text = String.format(Locale.US, "%+.1f", idx * step)
        }
        b.isoBar.onChange { applyManual() }
        b.ssBar.onChange { applyManual() }
        b.focusBar.onChange { applyManual() }
    }

    private fun SeekBar.onChange(block: () -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) block()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun setupChips() {
        b.histBtn.setOnClickListener { showHist = !showHist; bind() }
        b.zebraBtn.setOnClickListener { showZebra = !showZebra; bind() }
        b.peakBtn.setOnClickListener { showPeak = !showPeak; bind() }
        b.levelBtn.setOnClickListener { showLevel = !showLevel; updateChips() }
        b.micBtn.setOnClickListener { if (recording == null) { audioOn = !audioOn; updateChips() } }
        b.zoomBtn.setOnClickListener {
            zoomIdx = (zoomIdx + 1) % zoomSteps.size
            camera?.cameraControl?.setZoomRatio(zoomSteps[zoomIdx])
            updateChips()
        }
        b.timerBtn.setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            updateChips()
        }
        b.ratioBtn.setOnClickListener { ratio169 = !ratio169; bind() }
        b.extBtn.setOnClickListener {
            val base = CameraSelector.Builder().requireLensFacing(lens).build()
            for (i in 1..extModes.size) {
                val n = (extIdx + i) % extModes.size
                if (n == 0 || extMgr?.isExtensionAvailable(base, extModes[n]) == true) { extIdx = n; break }
            }
            bind()
        }
        b.fxBtn.setOnClickListener {
            for (i in 1..fxModes.size) {
                val n = (fxIdx + i) % fxModes.size
                if (n == 0 || availFx?.contains(fxModes[n]) == true) { fxIdx = n; break }
            }
            updateChips(); applyManual()
        }
        b.wbBtn.setOnClickListener {
            for (i in 1..wbModes.size) {
                val n = (wbIdx + i) % wbModes.size
                if (n == 0 || availWb?.contains(wbModes[n]) == true) { wbIdx = n; break }
            }
            updateChips(); applyManual()
        }
        b.stabBtn.setOnClickListener { if (recording == null) { stab = !stab; bind() } }
        b.galleryBtn.setOnClickListener {
            val u = lastUri
            if (u == null) Toast.makeText(this, "مفيش صور لسه", Toast.LENGTH_SHORT).show()
            else startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, contentResolver.getType(u))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }

    private fun updateChips() {
        b.zoomBtn.text = "🔍 ${zoomSteps[zoomIdx].toInt()}x"
        b.timerBtn.text = "⏱ " + if (timerSec == 0) "Off" else "${timerSec}s"
        b.ratioBtn.text = "▭ " + if (ratio169) "16:9" else "4:3"
        b.extBtn.text = "✨ ${extNames[extIdx]}"
        b.fxBtn.text = "🎨 ${fxNames[fxIdx]}"
        b.wbBtn.text = "WB ${wbNames[wbIdx]}"
        b.stabBtn.text = "🎥 Stab " + if (stab) "On" else "Off"
        fun TextView.tint(on: Boolean) = setTextColor(if (on) accent else 0xFFFFFFFF.toInt())
        b.histBtn.tint(showHist); b.zebraBtn.tint(showZebra); b.peakBtn.tint(showPeak)
        b.levelBtn.tint(showLevel); b.stabBtn.tint(stab); b.micBtn.tint(audioOn)
        b.micBtn.text = "🎙 " + if (audioOn) "On" else "Off"
        b.micBtn.visibility = if (mode == Mode.VIDEO) View.VISIBLE else View.GONE
        b.overlay.showHist = showHist
        b.overlay.showLevel = showLevel
        b.overlay.invalidate()
        val photo = mode == Mode.PHOTO
        b.extBtn.visibility = if (photo) View.VISIBLE else View.GONE
        b.timerBtn.visibility = if (mode == Mode.VIDEO) View.GONE else View.VISIBLE
        b.ratioBtn.visibility = if (mode == Mode.VIDEO) View.GONE else View.VISIBLE
        b.stabBtn.visibility = if (mode == Mode.VIDEO) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val r = Math.toDegrees(atan2(e.values[0].toDouble(), e.values[1].toDouble())).toFloat()
        b.overlay.roll = b.overlay.roll * 0.8f + r * 0.2f
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private val analyzer = ImageAnalysis.Analyzer { img ->
        try {
            if (!(showHist || showZebra || showPeak)) return@Analyzer
            val buf = img.planes[0].buffer
            val rs = img.planes[0].rowStride
            val w = img.width
            val h = img.height
            val rot = img.imageInfo.rotationDegrees
            val front = lens == CameraSelector.LENS_FACING_FRONT
            val ow = if (rot % 180 == 0) w else h
            val oh = if (rot % 180 == 0) h else w
            fun px(x0: Int, y0: Int): Int {
                val ox = (if (front) ow - 1 - x0 else x0).coerceIn(0, ow - 1)
                val oy = y0.coerceIn(0, oh - 1)
                val sx: Int
                val sy: Int
                when (rot) {
                    90 -> { sx = oy; sy = h - 1 - ox }
                    270 -> { sx = w - 1 - oy; sy = ox }
                    180 -> { sx = w - 1 - ox; sy = h - 1 - oy }
                    else -> { sx = ox; sy = oy }
                }
                return buf.get(sy * rs + sx).toInt() and 0xFF
            }
            var hist: IntArray? = null
            if (showHist) {
                val hs = IntArray(64)
                var y = 0
                while (y < oh) {
                    var x = 0
                    while (x < ow) { hs[px(x, y) shr 2]++; x += 6 }
                    y += 6
                }
                hist = hs
            }
            val gw = 120
            val gh = gw * oh / ow
            var pix: IntArray? = null
            if (showZebra || showPeak) {
                val a = IntArray(gw * gh)
                for (gy in 0 until gh) for (gx in 0 until gw) {
                    val ox = gx * ow / gw
                    val oy = gy * oh / gh
                    val v = px(ox, oy)
                    var c = 0
                    if (showZebra && v >= 240 && (gx + gy) % 4 < 2) c = 0xCCFF3B30.toInt()
                    if (showPeak && c == 0) {
                        val e = abs(v - px(ox + 3, oy)) + abs(v - px(ox, oy + 3))
                        if (e > 45) c = 0xFF30FF70.toInt()
                    }
                    a[gy * gw + gx] = c
                }
                pix = a
            }
            b.overlay.post { b.overlay.setData(hist, pix, gw, gh) }
        } finally {
            img.close()
        }
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (n == 0) { b.countdown.text = ""; done(); return }
        b.countdown.text = "$n"
        b.countdown.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) b.shutter.performClick()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- UI ----------

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val z = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
                camera?.cameraControl?.setZoomRatio(z * d.scaleFactor)
                return true
            }
        })
        b.preview.setOnTouchListener { v, e ->
            scale.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_UP && !scale.isInProgress &&
                e.eventTime - e.downTime < 300
            ) {
                focusAt(e.x, e.y)
                v.performClick()
            }
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val pt = b.preview.meteringPointFactory.createPoint(x, y)
        cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
        val ring = b.focusRing
        ring.translationX = x - ring.width / 2f
        ring.translationY = y - ring.height / 2f
        ring.scaleX = 1.4f
        ring.scaleY = 1.4f
        ring.alpha = 1f
        ring.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            ring.animate().alpha(0f).setStartDelay(700).setDuration(300).start()
        }.start()
    }

    private fun setupButtons() {
        b.shutter.setOnClickListener {
            b.shutter.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            when {
                mode == Mode.VIDEO -> toggleRecording()
                timerSec > 0 && b.countdown.text.isNullOrEmpty() -> countdown(timerSec) { takePhoto() }
                else -> takePhoto()
            }
        }
        b.flipBtn.setOnClickListener {
            lens = if (lens == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            bind()
        }
        b.gridBtn.setOnClickListener {
            val on = b.grid.visibility != View.VISIBLE
            b.grid.visibility = if (on) View.VISIBLE else View.GONE
            b.gridBtn.setTextColor(if (on) accent else 0xFFFFFFFF.toInt())
        }
        b.flashBtn.setOnClickListener {
            if (mode == Mode.VIDEO) {
                torch = !torch
                camera?.cameraControl?.enableTorch(torch)
                b.flashBtn.text = if (torch) "⚡ On" else "⚡ Off"
            } else {
                flash = when (flash) {
                    ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    else -> ImageCapture.FLASH_MODE_OFF
                }
                imageCapture?.flashMode = flash
                b.flashBtn.text = when (flash) {
                    ImageCapture.FLASH_MODE_AUTO -> "⚡ Auto"
                    ImageCapture.FLASH_MODE_ON -> "⚡ On"
                    else -> "⚡ Off"
                }
            }
        }
        b.tabPhoto.setOnClickListener { switchMode(Mode.PHOTO) }
        b.tabVideo.setOnClickListener { switchMode(Mode.VIDEO) }
        b.tabPro.setOnClickListener { switchMode(Mode.PRO) }
    }

    private fun switchMode(m: Mode) {
        if (recording != null || m == mode) return
        mode = m
        torch = false
        b.flashBtn.text = "⚡ Off"
        updateTabs()
        updateChips()
        bind()
    }

    private fun updateTabs() {
        val tabs = mapOf(Mode.PHOTO to b.tabPhoto, Mode.VIDEO to b.tabVideo, Mode.PRO to b.tabPro)
        tabs.forEach { (m, t: TextView) ->
            t.setTextColor(if (m == mode) accent else 0xFFAAAAAA.toInt())
        }
        b.shutter.setBackgroundResource(
            if (mode == Mode.VIDEO) R.drawable.shutter_rec else R.drawable.shutter_photo
        )
    }

    // ---------- Capture ----------

    private fun stamp() =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/APlusCam")
        }
        val meta = ImageCapture.Metadata().apply {
            isReversedHorizontal = lens == CameraSelector.LENS_FACING_FRONT
        }
        val opts = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
        ).setMetadata(meta).build()

        b.shutter.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).withEndAction {
            b.shutter.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()

        ic.takePicture(opts, main, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                lastUri = r.savedUri
                Toast.makeText(this@MainActivity, "اتحفظت ✔", Toast.LENGTH_SHORT).show()
            }
            override fun onError(e: ImageCaptureException) {
                Toast.makeText(this@MainActivity, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun toggleRecording() {
        val vc = videoCapture ?: return
        recording?.let {
            it.stop()
            return
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/APlusCam")
        }
        val out = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(cv).build()

        var pending = vc.output.prepareRecording(this, out)
        if (audioOn && granted(Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled()

        recording = pending.start(main) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> setRecordingUi(true)
                is VideoRecordEvent.Status -> {
                    val sec = ev.recordingStats.recordedDurationNanos / 1_000_000_000L
                    b.info.text = String.format(Locale.US, "● %02d:%02d", sec / 60, sec % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    if (!ev.hasError()) lastUri = ev.outputResults.outputUri
                    setRecordingUi(false)
                    val msg = if (ev.hasError()) "خطأ في الفيديو" else "الفيديو اتحفظ ✔"
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
                else -> {}
            }
        }
    }

    private fun setRecordingUi(on: Boolean) {
        b.shutter.setBackgroundResource(if (on) R.drawable.shutter_stop else R.drawable.shutter_rec)
        b.flipBtn.isEnabled = !on
        if (!on) b.info.text = ""
    }
}
