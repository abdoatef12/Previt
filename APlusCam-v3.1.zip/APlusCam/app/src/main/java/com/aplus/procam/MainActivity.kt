package com.aplus.procam

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.TonemapCurve
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Range
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.aplus.procam.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.log10
import kotlin.math.atan2
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity(), SensorEventListener {

    private enum class Mode { PHOTO, VIDEO }

    private class Setting(
        val section: String,
        val title: String,
        val names: () -> List<String>,
        val get: () -> Int,
        val set: (Int) -> Unit
    )

    private lateinit var b: ActivityMainBinding
    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lastUri: Uri? = null

    // state
    private var mode = Mode.PHOTO
    private var lens = CameraSelector.LENS_FACING_BACK
    private var manual = false
    private var focusManual = false
    private var ratio169 = false
    private var timerIdx = 0
    private var flashIdx = 0
    private var resIdx = 0
    private var qualitiesInit = false
    private var fps = 30
    private var angleIdx = 4
    private var wbIdx = 0
    private var fxIdx = 0
    private var extIdx = 0
    private var stabIdx = 1            // 0 Off, 1 OIS, 2 EIS, 3 OIS+EIS
    private var qualityBoost = true
    private var toneIdx = 0
    private var bitrateIdx = 1
    private var extActive = false
    private var displayHz = ""
    private var audioOn = true
    private var gridIdx = 0
    private var guideIdx = 0
    private var safeZone = false
    private var showFalse = false
    private var showWave = false
    private var aeLock = false
    private var awbLock = false
    private var cleanFeed = false
    private var zebraIdx = 3
    private var peakIdx = 1
    private var desqIdx = 0
    private var camIdIdx = 0
    private var clipNo = 1
    private var pinched = false
    private var showHist = false
    private var showZebra = false
    private var showPeak = false
    private var showLevel = false

    // capabilities
    private var videoQualities: List<Quality> = emptyList()
    private var fpsRanges: List<Range<Int>> = emptyList()
    private var fpsOptions: List<Int> = listOf(30)
    private var isoRange: Range<Int>? = null
    private var expRange: Range<Long>? = null
    private var minFocus = 0f
    private var availFx: IntArray? = null
    private var availWb: IntArray? = null
    private var availOis: IntArray? = null
    private var availVstab: IntArray? = null
    private var availNr: IntArray? = null
    private var availEdge: IntArray? = null
    private var availAb: IntArray? = null
    private var availHot: IntArray? = null
    private var availShade: IntArray? = null
    private var availTone: IntArray? = null

    private val timerOpts = listOf(0, 3, 10)
    private val gridNames = listOf("Off", "Thirds", "Center Cross", "Golden Ratio", "Diagonals")
    private val guideNames = listOf("Off", "2.39:1", "1.85:1", "16:9", "4:3", "1:1", "9:16")
    private val zebraVals = listOf(70, 80, 90, 95, 100)
    private val zebraNames = zebraVals.map { "$it%" }
    private val peakVals = listOf(70, 45, 25)
    private val peakNames = listOf("Low", "Medium", "High")
    private val desqVals = listOf(1f, 1.33f, 1.5f, 1.8f, 2f)
    private val desqNames = listOf("Off", "1.33x", "1.5x", "1.8x", "2x")
    private val prefs by lazy { getSharedPreferences("cam", MODE_PRIVATE) }
    private val stabNames = listOf("Off", "Optical (OIS)", "Electronic (EIS)", "OIS + EIS")
    private val toneNames = listOf("Natural", "Soft", "Punch", "Strong")
    private val toneAmt = listOf(0f, -0.25f, 0.3f, 0.55f)
    private val bitrateNames = listOf("Auto", "High", "Max")
    private val flashModes = listOf(ImageCapture.FLASH_MODE_OFF, ImageCapture.FLASH_MODE_AUTO, ImageCapture.FLASH_MODE_ON)
    private val angles = listOf(45f, 90f, 144f, 172.8f, 180f, 270f, 360f)
    private val wbModes = listOf(1, 5, 6, 2, 3)
    private val wbNames = listOf("Auto", "Daylight 5600K", "Cloudy 6500K", "Tungsten 3200K", "Fluorescent 4000K")
    private val wbShort = listOf("AWB", "5600K", "6500K", "3200K", "4000K")
    private val fxModes = listOf(0, 1, 2, 4, 5, 8)
    private val fxNames = listOf("Off", "Mono", "Negative", "Sepia", "Poster", "Aqua")
    private val extModes = listOf(ExtensionMode.NONE, ExtensionMode.AUTO, ExtensionMode.NIGHT,
        ExtensionMode.HDR, ExtensionMode.BOKEH, ExtensionMode.FACE_RETOUCH)
    private val extNames = listOf("Off", "Auto", "Night", "HDR", "Portrait", "Face Retouch")

    private val main by lazy { ContextCompat.getMainExecutor(this) }
    private val analysisExec = Executors.newSingleThreadExecutor()
    private val accent = 0xFF4DA3FF.toInt()
    private val red = 0xFFFF3B30.toInt()

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera()
        else {
            Toast.makeText(this, "محتاج إذن الكاميرا", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestHighRefresh()
        clipNo = prefs.getInt("clip", 1)
        camIdIdx = prefs.getInt("camId", 0).coerceIn(0, 3)
        setupTouch()
        setupButtons()
        setupSliders()
        renderSettings()
        updateUi()
        if (granted(Manifest.permission.CAMERA)) startCamera()
        else permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ================= Camera =================

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            provider = p
            val ef = ExtensionsManager.getInstanceAsync(this, p)
            ef.addListener({
                extMgr = ef.get()
                bind()
            }, main)
        }, main)
    }

    private fun qName(q: Quality) = when (q) {
        Quality.UHD -> "4K"
        Quality.FHD -> "1080p"
        Quality.HD -> "720p"
        else -> "480p"
    }

    private fun bind() {
        val p = provider ?: return
        p.unbindAll()

        val base = CameraSelector.Builder().requireLensFacing(lens).build()
        val extMode = extModes[extIdx]
        val selector = if (mode == Mode.PHOTO && !manual && extMode != ExtensionMode.NONE &&
            extMgr?.isExtensionAvailable(base, extMode) == true
        ) extMgr!!.getExtensionEnabledCameraSelector(base, extMode) else base

        extActive = selector !== base
        val aspect = AspectRatioStrategy(
            if (ratio169 || mode == Mode.VIDEO) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3,
            AspectRatioStrategy.FALLBACK_RULE_AUTO
        )
        // preview: normal size for smoothness
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build()
        // photo: always the highest resolution the sensor offers
        val rsMax = ResolutionSelector.Builder().setAspectRatioStrategy(aspect)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY).build()
        val preview = Preview.Builder().setResolutionSelector(rs).build()
            .also { it.setSurfaceProvider(b.preview.surfaceProvider) }
        val cases = mutableListOf<UseCase>(preview)

        if (mode == Mode.VIDEO) {
            val q = videoQualities.getOrNull(resIdx) ?: Quality.FHD
            val rb = Recorder.Builder().setQualitySelector(
                QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
            )
            if (bitrateIdx > 0) rb.setTargetVideoEncodingBitRate(targetBitrate(q))
            val vb = VideoCapture.Builder(rb.build())
            val preInfo = try { base.filter(p.availableCameraInfos).firstOrNull() } catch (e: Exception) { null }
            val preVstab = preInfo?.let {
                Camera2CameraInfo.from(it).getCameraCharacteristic(
                    CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            }
            if ((stabIdx == 2 || stabIdx == 3) &&
                preVstab?.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
            ) {
                Camera2Interop.Extender(vb).setCaptureRequestOption(
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
                )
            }
            videoCapture = vb.build()
            imageCapture = null
            cases += videoCapture!!
        } else {
            imageCapture = ImageCapture.Builder()
                .setResolutionSelector(rsMax)
                .setJpegQuality(100)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flashModes[flashIdx])
                .build()
            videoCapture = null
            cases += imageCapture!!
        }

        val anyTool = showHist || showZebra || showPeak || showWave || showFalse
        if (anyTool && selector === base) {
            cases += ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build().also { it.setAnalyzer(analysisExec, analyzer) }
        }

        camera = try {
            p.bindToLifecycle(this, selector, *cases.toTypedArray())
        } catch (e: Exception) {
            if (anyTool && selector === base) {
                showHist = false; showZebra = false; showPeak = false; showWave = false; showFalse = false
                Toast.makeText(this, "الأدوات دي مش مدعومة هنا", Toast.LENGTH_SHORT).show()
                updateUi(); renderSettings(); bind()
            } else if (extIdx != 0) {
                extIdx = 0
                updateUi(); renderSettings(); bind()
            } else {
                Toast.makeText(this, "مش قادر أفتح الكاميرا: ${e.message}", Toast.LENGTH_LONG).show()
            }
            return
        }

        val cam = camera!!
        val c2 = Camera2CameraInfo.from(cam.cameraInfo)
        isoRange = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        expRange = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        minFocus = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        availFx = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS)
        availWb = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)
        availOis = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        availVstab = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        availNr = c2.getCameraCharacteristic(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
        availEdge = c2.getCameraCharacteristic(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
        availAb = c2.getCameraCharacteristic(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES)
        availHot = c2.getCameraCharacteristic(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES)
        availShade = c2.getCameraCharacteristic(CameraCharacteristics.SHADING_AVAILABLE_MODES)
        availTone = c2.getCameraCharacteristic(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)
        fpsRanges = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ?.toList() ?: emptyList()
        fpsOptions = listOf(24, 30, 60, 90, 120).filter { f -> fpsRanges.any { it.lower <= f && it.upper >= f } }
            .ifEmpty { listOf(30) }
        if (fps !in fpsOptions) fps = fpsOptions.first()

        val newQ = QualitySelector.getSupportedQualities(cam.cameraInfo)
        val changed = newQ != videoQualities
        videoQualities = newQ
        if (!qualitiesInit && newQ.isNotEmpty()) {
            resIdx = newQ.indexOf(Quality.FHD).coerceAtLeast(0)
            qualitiesInit = true
        }
        if (resIdx >= newQ.size) resIdx = 0

        cam.cameraInfo.zoomState.observe(this) { z ->
            b.zoomLabel.text = String.format(Locale.US, "%.1fx", z.zoomRatio)
        }
        if (mode == Mode.VIDEO) cam.cameraControl.enableTorch(flashIdx == 2)

        if (changed) renderSettings()
        refreshPanel()
        applyOptions()
        updateUi()
        if (!anyTool) b.overlay.clear()
    }

    // ================= Helpers: quality / display =================

    private fun has(a: IntArray?, v: Int) = a?.contains(v) == true

    /** sRGB-encoded S-curve. c>0 = more contrast, c<0 = softer. */
    private fun toneCurve(c: Float): TonemapCurve {
        val n = 64
        val pts = FloatArray(n * 2)
        for (i in 0 until n) {
            val x = i / (n - 1.0)
            val g = if (x <= 0.0031308) 12.92 * x else 1.055 * x.pow(1.0 / 2.4) - 0.055
            val y = (g - c.toDouble() * sin(2.0 * PI * g) / (2.0 * PI)).coerceIn(0.0, 1.0)
            pts[2 * i] = x.toFloat()
            pts[2 * i + 1] = y.toFloat()
        }
        return TonemapCurve(pts, pts.copyOf(), pts.copyOf())
    }

    private fun targetBitrate(q: Quality): Int {
        val base = when (q) {
            Quality.UHD -> 60_000_000
            Quality.FHD -> 24_000_000
            Quality.HD -> 10_000_000
            else -> 4_000_000
        }
        val boost = if (bitrateIdx == 2) 1.6 else 1.0
        val fpsScale = if (fps > 30) fps / 30.0 else 1.0
        return (base * boost * fpsScale).toInt().coerceAtMost(120_000_000)
    }

    /** Ask the display for its highest refresh rate (90 Hz on Galaxy A16) so the UI/preview is smooth. */
    private fun requestHighRefresh() {
        try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            val cur = d.mode
            val best = d.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .maxByOrNull { it.refreshRate }
            val lp = window.attributes
            if (best != null) {
                lp.preferredDisplayModeId = best.modeId
                lp.preferredRefreshRate = best.refreshRate
                displayHz = "${best.refreshRate.roundToInt()} Hz"
            } else {
                lp.preferredRefreshRate = 90f
                displayHz = "90 Hz"
            }
            window.attributes = lp
        } catch (e: Exception) {
            displayHz = "Default"
        }
    }

    private fun supportText(): String {
        val ois = has(availOis, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
        val eis = has(availVstab, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        return "OIS ${if (ois) "✔" else "✘"}  EIS ${if (eis) "✔" else "✘"}"
    }

    // ================= Manual controls =================

    private fun isoValue(): Int {
        val r = isoRange ?: return 100
        val lo = r.lower.toDouble()
        val hi = minOf(r.upper, 3200).toDouble()
        return (lo * (hi / lo).pow(b.isoBar.progress / 100.0)).roundToInt()
    }

    private fun sliderShutterNs(): Long {
        val r = expRange ?: return 10_000_000L
        val lo = maxOf(r.lower, 250_000L).toDouble()
        val hi = minOf(r.upper, 250_000_000L).toDouble()
        return (lo * (hi / lo).pow(b.ssBar.progress / 100.0)).toLong()
    }

    private fun shutterText(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/${(1 / s).roundToInt()}"
    }

    private fun applyOptions() {
        val cam = camera ?: return
        val ctl = Camera2CameraControl.from(cam.cameraControl)
        val o = CaptureRequestOptions.Builder()
        if (mode == Mode.VIDEO) {
            fpsRanges.filter { it.lower <= fps && it.upper >= fps }
                .minByOrNull { it.upper - it.lower }
                ?.let { o.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        }
        // ---- optical + electronic stabilizer
        val wantOis = stabIdx == 1 || stabIdx == 3
        val wantEis = stabIdx == 2 || stabIdx == 3
        if (has(availOis, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) ||
            has(availOis, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
        ) {
            if (wantOis && has(availOis, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON))
                o.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            else if (!wantOis && has(availOis, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF))
                o.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
        }
        if (mode == Mode.VIDEO && wantEis &&
            has(availVstab, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON))
            o.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)

        // ---- max image quality pipeline (photo only, not with vendor extensions)
        if (mode == Mode.PHOTO && !extActive) {
            if (qualityBoost) {
                if (has(availNr, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY))
                    o.setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE,
                        CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                if (has(availEdge, CaptureRequest.EDGE_MODE_HIGH_QUALITY))
                    o.setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
                if (has(availAb, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY))
                    o.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                        CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
                if (has(availHot, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY))
                    o.setCaptureRequestOption(CaptureRequest.HOT_PIXEL_MODE,
                        CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY)
                if (has(availShade, CaptureRequest.SHADING_MODE_HIGH_QUALITY))
                    o.setCaptureRequestOption(CaptureRequest.SHADING_MODE, CaptureRequest.SHADING_MODE_HIGH_QUALITY)
            }
            if (toneIdx != 0 && has(availTone, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE)) {
                o.setCaptureRequestOption(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE)
                o.setCaptureRequestOption(CaptureRequest.TONEMAP_CURVE, toneCurve(toneAmt[toneIdx]))
            } else if (qualityBoost && has(availTone, CaptureRequest.TONEMAP_MODE_HIGH_QUALITY)) {
                o.setCaptureRequestOption(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_HIGH_QUALITY)
            }
        }

        if (aeLock) o.setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, true)
        if (awbLock) o.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, true)
        if (fxIdx != 0) o.setCaptureRequestOption(CaptureRequest.CONTROL_EFFECT_MODE, fxModes[fxIdx])
        if (wbIdx != 0) o.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, wbModes[wbIdx])

        var shutTxt = "Auto"
        var isoTxt = "Auto"
        val er = expRange
        if (manual && isoRange != null && er != null) {
            val iso = isoValue()
            val ns = if (mode == Mode.VIDEO) {
                (angles[angleIdx] / 360.0 * (1e9 / fps)).toLong().coerceIn(er.lower, er.upper)
            } else sliderShutterNs()
            o.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            o.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            o.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
            b.isoVal.text = iso.toString()
            b.ssVal.text = shutterText(ns)
            shutTxt = shutterText(ns)
            isoTxt = iso.toString()
        }
        if (focusManual && minFocus > 0f) {
            val fp = b.focusBar.progress
            o.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            o.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * fp / 100f)
            b.focusVal.text = "$fp%"
        }
        ctl.setCaptureRequestOptions(o.build())
        b.valShut.text = shutTxt
        b.valIso.text = isoTxt
    }

    private fun refreshPanel() {
        val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange
        val evOk = r != null && r.upper != r.lower
        b.evRow.visibility = if (!manual && evOk) View.VISIBLE else View.GONE
        b.isoRow.visibility = if (manual) View.VISIBLE else View.GONE
        b.ssRow.visibility = if (manual && mode == Mode.PHOTO) View.VISIBLE else View.GONE
        b.focusRow.visibility = if (focusManual && minFocus > 0f) View.VISIBLE else View.GONE
        val any = b.evRow.visibility == View.VISIBLE || manual || b.focusRow.visibility == View.VISIBLE
        b.panel.visibility = if (any && !cleanFeed) View.VISIBLE else View.GONE
    }

    private fun setupSliders() {
        b.evBar.onChange {
            val cam = camera ?: return@onChange
            val r = cam.cameraInfo.exposureState.exposureCompensationRange
            val idx = r.lower + ((r.upper - r.lower) * b.evBar.progress / 100f).roundToInt()
            cam.cameraControl.setExposureCompensationIndex(idx)
            val step = cam.cameraInfo.exposureState.exposureCompensationStep.toFloat()
            b.evVal.text = String.format(Locale.US, "%+.1f", idx * step)
        }
        b.isoBar.onChange { applyOptions() }
        b.ssBar.onChange { applyOptions() }
        b.focusBar.onChange { applyOptions() }
    }

    private fun SeekBar.onChange(block: () -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) block()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    // ================= UI =================

    private fun updateUi() {
        b.valRes.text = if (mode == Mode.VIDEO)
            (videoQualities.getOrNull(resIdx)?.let { qName(it) } ?: "1080p")
        else if (ratio169) "16:9" else "4:3"
        b.valFps.text = fps.toString()
        b.valWb.text = wbShort[wbIdx]
        b.grid.gridType = gridIdx
        b.grid.guideIdx = guideIdx
        b.grid.safeZone = safeZone
        val gridAny = gridIdx != 0 || guideIdx != 0 || safeZone
        b.grid.visibility = if (gridAny && !cleanFeed) View.VISIBLE else View.GONE
        b.overlay.visibility = if (cleanFeed) View.GONE else View.VISIBLE
        b.topBar.visibility = if (cleanFeed) View.GONE else View.VISIBLE
        b.zoomLabel.visibility = if (cleanFeed) View.GONE else View.VISIBLE
        b.overlay.showWave = showWave
        b.preview.scaleY = 1f / desqVals[desqIdx]
        if (recording == null) {
            b.info.setTextColor(0xFFFFFFFF.toInt())
            b.info.text = hudText()
        }
        b.overlay.showHist = showHist
        b.overlay.showLevel = showLevel
        b.overlay.invalidate()
        b.modeBtn.text = if (mode == Mode.PHOTO) "🎥" else "📷"
        b.panelBtn.setTextColor(if (manual) accent else 0xFFFFFFFF.toInt())
        if (recording == null) {
            b.shutter.setBackgroundResource(
                if (mode == Mode.VIDEO) R.drawable.shutter_rec else R.drawable.shutter_photo
            )
        }
        val onSettings = b.settingsRoot.visibility == View.VISIBLE
        b.tabCam.setTextColor(if (!onSettings) accent else 0xFF9A9AA5.toInt())
        b.tabSet.setTextColor(if (onSettings) accent else 0xFF9A9AA5.toInt())
    }

    private fun afterChange() {
        updateUi()
        renderSettings()
        bind()
    }

    private fun settings(): List<Setting> {
        val onOff = listOf("Off", "On")
        fun tog(sec: String, t: String, g: () -> Boolean, s: (Boolean) -> Unit) =
            Setting(sec, t, { onOff }, { if (g()) 1 else 0 }, { s(it == 1) })
        return listOf(
            Setting("Input", "Resolution",
                { videoQualities.map { qName(it) }.ifEmpty { listOf("1080p") } },
                { resIdx }, { if (videoQualities.isNotEmpty()) resIdx = it }),
            Setting("Input", "Frame Rate", { fpsOptions.map { "$it fps" } },
                { fpsOptions.indexOf(fps).coerceAtLeast(0) }, { fps = fpsOptions[it] }),
            Setting("Input", "Shutter Angle",
                { angles.map { if (it % 1f == 0f) "${it.toInt()}°" else "$it°" } },
                { angleIdx }, { angleIdx = it }),
            tog("Input", "Manual Exposure (ISO / Shutter)", { manual }, { manual = it }),
            Setting("Input", "White Balance", { wbNames }, { wbIdx }, { wbIdx = it }),

            tog("Camera Controls", "Manual Focus", { focusManual }, { focusManual = it }),
            tog("Camera Controls", "Focus Peaking", { showPeak }, { showPeak = it }),
            tog("Camera Controls", "Zebra", { showZebra }, { showZebra = it }),
            tog("Camera Controls", "Histogram", { showHist }, { showHist = it }),
            Setting("Camera Controls", "Grid", { gridNames }, { gridIdx }, { gridIdx = it }),
            Setting("Camera Controls", "Frame Guide", { guideNames }, { guideIdx }, { guideIdx = it }),
            tog("Camera Controls", "Safe Zone (90% / 80%)", { safeZone }, { safeZone = it }),
            tog("Camera Controls", "False Color", { showFalse }, { showFalse = it }),
            tog("Camera Controls", "Waveform", { showWave }, { showWave = it }),
            Setting("Camera Controls", "Zebra Level", { zebraNames }, { zebraIdx }, { zebraIdx = it }),
            Setting("Camera Controls", "Peaking Sensitivity", { peakNames }, { peakIdx }, { peakIdx = it }),
            tog("Camera Controls", "AE Lock (exposure)", { aeLock }, { aeLock = it }),
            tog("Camera Controls", "AWB Lock (white balance)", { awbLock }, { awbLock = it }),
            Setting("Camera Controls", "Anamorphic Desqueeze", { desqNames }, { desqIdx }, { desqIdx = it }),
            tog("Camera Controls", "Clean Feed (hide UI)", { cleanFeed }, { cleanFeed = it }),
            tog("Camera Controls", "Level", { showLevel }, { showLevel = it }),
            Setting("Camera Controls", "Display Look", { fxNames }, { fxIdx }, { fxIdx = it }),
            Setting("Camera Controls", "Night / HDR / Portrait", { extNames }, { extIdx }, { extIdx = it }),
            Setting("Camera Controls", "Photo Aspect Ratio", { listOf("4:3", "16:9") },
                { if (ratio169) 1 else 0 }, { ratio169 = it == 1 }),
            Setting("Camera Controls", "Timer", { timerOpts.map { if (it == 0) "Off" else "${it}s" } },
                { timerIdx }, { timerIdx = it }),
            Setting("Camera Controls", "Flash / Torch", { listOf("Off", "Auto", "On") },
                { flashIdx }, { flashIdx = it }),

            Setting("Quality", "Stabilizer", { stabNames }, { stabIdx }, { stabIdx = it }),
            Setting("Quality", "Stabilizer Support (this lens)", { listOf(supportText()) }, { 0 }, { }),
            tog("Quality", "Quality Boost (HQ noise / sharpness / tone)", { qualityBoost }, { qualityBoost = it }),
            Setting("Quality", "Contrast Curve", { toneNames }, { toneIdx }, { toneIdx = it }),
            Setting("Quality", "Photo Size", { listOf("Max resolution") }, { 0 }, { }),
            Setting("Quality", "JPEG Quality", { listOf("100%") }, { 0 }, { }),
            Setting("Quality", "Video Bitrate", { bitrateNames }, { bitrateIdx }, { bitrateIdx = it }),
            Setting("Quality", "Display Refresh", { listOf(displayHz.ifEmpty { "Default" }) }, { 0 }, { }),

            tog("Audio", "Microphone", { audioOn }, { audioOn = it }),
            Setting("Audio", "Audio Source", { listOf("Built-in Mic") }, { 0 }, { }),

            Setting("Recording", "Camera ID", { listOf("A", "B", "C", "D") }, { camIdIdx },
                { camIdIdx = it; prefs.edit().putInt("camId", it).apply() }),
            Setting("Recording", "Clip Counter",
                { listOf("Next: ${'A' + camIdIdx}${String.format(Locale.US, "%03d", clipNo)}", "Reset to 001") },
                { 0 }, { if (it == 1) { clipNo = 1; prefs.edit().putInt("clip", 1).apply() } }),
            Setting("Recording", "Codec", { listOf("Auto (H.264)") }, { 0 }, { }),
            Setting("Recording", "Bit Depth", { listOf("8 bit") }, { 0 }, { }),
            Setting("Recording", "Media Location", { listOf("Phone Storage") }, { 0 }, { })
        )
    }

    private fun renderSettings() {
        val d = resources.displayMetrics.density
        val list = b.settingsList
        list.removeAllViews()
        var last = ""
        for (s in settings()) {
            if (s.section != last) {
                last = s.section
                list.addView(TextView(this).apply {
                    text = s.section
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 18f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding((4 * d).toInt(), (22 * d).toInt(), 0, (8 * d).toInt())
                })
            }
            val names = s.names()
            val value = names.getOrNull(s.get()) ?: names.firstOrNull() ?: ""
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding((16 * d).toInt(), (15 * d).toInt(), (16 * d).toInt(), (15 * d).toInt())
                setBackgroundColor(0xFF16161C.toInt())
                setOnClickListener {
                    if (names.size > 1) {
                        s.set((s.get() + 1) % names.size)
                        afterChange()
                    }
                }
            }
            row.addView(TextView(this).apply {
                text = s.title
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 16f
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply {
                text = value
                setTextColor(if (names.size > 1) accent else 0xFF8A8A95.toInt())
                textSize = 16f
            })
            list.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (2 * d).toInt() })
        }
    }

    private fun showSettings(on: Boolean) {
        b.settingsRoot.visibility = if (on) View.VISIBLE else View.GONE
        updateUi()
    }

    private fun cycle(n: Int, cur: Int) = (cur + 1) % n.coerceAtLeast(1)

    private fun setupButtons() {
        b.cellRes.setOnClickListener {
            if (mode == Mode.VIDEO) resIdx = cycle(videoQualities.size, resIdx) else ratio169 = !ratio169
            afterChange()
        }
        b.cellFps.setOnClickListener {
            fps = fpsOptions[cycle(fpsOptions.size, fpsOptions.indexOf(fps).coerceAtLeast(0))]
            afterChange()
        }
        b.cellShut.setOnClickListener { manual = !manual; afterChange() }
        b.cellIso.setOnClickListener { manual = !manual; afterChange() }
        b.cellWb.setOnClickListener {
            for (i in 1..wbModes.size) {
                val n = (wbIdx + i) % wbModes.size
                if (n == 0 || availWb?.contains(wbModes[n]) == true) { wbIdx = n; break }
            }
            afterChange()
        }
        b.panelBtn.setOnClickListener { manual = !manual; afterChange() }
        b.zoomLabel.setOnClickListener {
            val zs = camera?.cameraInfo?.zoomState?.value ?: return@setOnClickListener
            val levels = buildList {
                if (zs.minZoomRatio < 0.95f) add(zs.minZoomRatio)
                add(1f); add(2f); add(5f)
            }.filter { it <= zs.maxZoomRatio }
            val next = levels.firstOrNull { it > zs.zoomRatio + 0.05f } ?: levels.first()
            camera?.cameraControl?.setZoomRatio(next)
        }
        b.modeBtn.setOnClickListener {
            if (recording == null) {
                mode = if (mode == Mode.PHOTO) Mode.VIDEO else Mode.PHOTO
                afterChange()
            }
        }
        b.flipBtn.setOnClickListener {
            if (recording == null) {
                lens = if (lens == CameraSelector.LENS_FACING_BACK)
                    CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
                bind()
            }
        }
        b.shutter.setOnClickListener {
            b.shutter.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            when {
                mode == Mode.VIDEO -> toggleRecording()
                timerOpts[timerIdx] > 0 && b.countdown.text.isNullOrEmpty() ->
                    countdown(timerOpts[timerIdx]) { takePhoto() }
                else -> takePhoto()
            }
        }
        b.galleryBtn.setOnClickListener { openGallery() }
        b.tabCam.setOnClickListener { showSettings(false) }
        b.tabMedia.setOnClickListener { openGallery() }
        b.tabEdit.setOnClickListener { openEditor() }
        b.galleryBtn.setOnLongClickListener { openEditor(); true }
        b.tabSet.setOnClickListener { showSettings(true) }
        b.settingsBack.setOnClickListener { showSettings(false) }
    }

    private fun openEditor() {
        val i = Intent(this, EditActivity::class.java)
        lastUri?.let { u ->
            if (contentResolver.getType(u)?.startsWith("image") == true) i.data = u
        }
        startActivity(i)
    }

    private fun openGallery() {
        try {
            val u = lastUri
            if (u != null) startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, contentResolver.getType(u))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ) else startActivity(
                Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "مش لاقي المعرض", Toast.LENGTH_SHORT).show()
        }
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (n == 0) { b.countdown.text = ""; done(); return }
        b.countdown.text = "$n"
        b.countdown.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) b.shutter.performClick()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val z = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
                camera?.cameraControl?.setZoomRatio(z * d.scaleFactor)
                pinched = true
                return true
            }
        })
        b.preview.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) pinched = false
            scale.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_UP && !scale.isInProgress && !pinched) {
                val held = e.eventTime - e.downTime
                if (held < 300) { focusAt(e.x, e.y, false); v.performClick() }
                else if (held >= 600) focusAt(e.x, e.y, true)   // long-press = AE/AF lock
            }
            true
        }
    }

    private fun focusAt(x: Float, y: Float, lock: Boolean) {
        val cam = camera ?: return
        val pt = b.preview.meteringPointFactory.createPoint(x, y)
        val fb = FocusMeteringAction.Builder(pt)
        if (lock) {
            fb.disableAutoCancel()
            Toast.makeText(this, "AE/AF Lock 🔒", Toast.LENGTH_SHORT).show()
        }
        cam.cameraControl.startFocusAndMetering(fb.build())
        val ring = b.focusRing
        ring.translationX = x - ring.width / 2f
        ring.translationY = y - ring.height / 2f
        ring.scaleX = 1.4f
        ring.scaleY = 1.4f
        ring.alpha = 1f
        ring.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            ring.animate().alpha(0f).setStartDelay(700).setDuration(300).start()
        }.start()
    }

    // ================= Sensors / analysis =================

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val r = Math.toDegrees(atan2(e.values[0].toDouble(), e.values[1].toDouble())).toFloat()
        b.overlay.roll = b.overlay.roll * 0.8f + r * 0.2f
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private val analyzer = ImageAnalysis.Analyzer { img ->
        try {
            if (!(showHist || showZebra || showPeak || showWave || showFalse)) return@Analyzer
            val buf = img.planes[0].buffer
            val rs = img.planes[0].rowStride
            val w = img.width
            val h = img.height
            val rot = img.imageInfo.rotationDegrees
            val front = lens == CameraSelector.LENS_FACING_FRONT
            val ow = if (rot % 180 == 0) w else h
            val oh = if (rot % 180 == 0) h else w
            fun px(x0: Int, y0: Int): Int {
                val ox = (if (front) ow - 1 - x0 else x0).coerceIn(0, ow - 1)
                val oy = y0.coerceIn(0, oh - 1)
                val sx: Int
                val sy: Int
                when (rot) {
                    90 -> { sx = oy; sy = h - 1 - ox }
                    270 -> { sx = w - 1 - oy; sy = ox }
                    180 -> { sx = w - 1 - ox; sy = h - 1 - oy }
                    else -> { sx = ox; sy = oy }
                }
                return buf.get(sy * rs + sx).toInt() and 0xFF
            }
            var hist: IntArray? = null
            if (showHist) {
                val hs = IntArray(64)
                var y = 0
                while (y < oh) {
                    var x = 0
                    while (x < ow) { hs[px(x, y) shr 2]++; x += 6 }
                    y += 6
                }
                hist = hs
            }
            var wave: IntArray? = null
            if (showWave) {
                val wv = IntArray(AnalysisOverlay.WC * AnalysisOverlay.WL)
                for (gx in 0 until AnalysisOverlay.WC) {
                    val ox = gx * ow / AnalysisOverlay.WC
                    var y = 0
                    while (y < oh) {
                        val lv = px(ox, y) * (AnalysisOverlay.WL - 1) / 255
                        wv[gx * AnalysisOverlay.WL + lv]++
                        y += 8
                    }
                }
                wave = wv
            }
            val gw = 160
            val gh = gw * oh / ow
            var pix: IntArray? = null
            val zebraThr = zebraVals[zebraIdx] * 255 / 100
            val peakThr = peakVals[peakIdx]
            if (showZebra || showPeak || showFalse) {
                val a = IntArray(gw * gh)
                for (gy in 0 until gh) for (gx in 0 until gw) {
                    val ox = gx * ow / gw
                    val oy = gy * oh / gh
                    val v = px(ox, oy)
                    var c = 0
                    if (showFalse) {
                        c = falseColor(v)
                    } else {
                        if (showZebra && v >= zebraThr && (gx + gy) % 4 < 2) c = 0xCCFF3B30.toInt()
                        if (showPeak && c == 0) {
                            val e = abs(v - px(ox + 3, oy)) + abs(v - px(ox, oy + 3))
                            if (e > peakThr) c = 0xFF30FF70.toInt()
                        }
                    }
                    a[gy * gw + gx] = c
                }
                pix = a
            }
            b.overlay.post { b.overlay.setData(hist, pix, gw, gh, wave) }
        } finally {
            img.close()
        }
    }

    /** Exposure false-colour bands (purple = crushed ... red = clipped). */
    private fun falseColor(v: Int): Int = when {
        v < 8 -> 0xB08A2BE2.toInt()
        v < 30 -> 0xB01E5AFF.toInt()
        v < 70 -> 0xB000B7C3.toInt()
        v < 100 -> 0x40808080
        v < 130 -> 0xB02ECC40.toInt()
        v < 165 -> 0x40808080
        v < 195 -> 0xB0FF7EB9.toInt()
        v < 235 -> 0xB0FFE600.toInt()
        v < 250 -> 0xB0FF9500.toInt()
        else -> 0xD0FF1E1E.toInt()
    }

    @Suppress("DEPRECATION")
    private fun hudText(): String {
        return try {
            val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
            val bat = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val st = android.os.StatFs(android.os.Environment.getExternalStorageDirectory().path)
            val free = st.availableBytes
            var t = String.format(Locale.US, "🔋 %d%%   💾 %.1f GB", bat, free / 1_073_741_824.0)
            if (mode == Mode.VIDEO) {
                val q = videoQualities.getOrNull(resIdx) ?: Quality.FHD
                val mins = free / (targetBitrate(q) / 8.0) / 60.0
                t += String.format(Locale.US, "   ⏱ ~%d min", mins.toLong())
            }
            t
        } catch (e: Exception) { "" }
    }

    private fun meterBar(amp: Double): String {
        val lin = if (amp > 1.0) amp / 32767.0 else amp   // CameraX reports 0..1
        val db = if (lin <= 0.0) -90.0 else 20 * log10(lin)
        val n = ((db + 60) / 6).roundToInt().coerceIn(0, 10)
        return "▮".repeat(n) + "▯".repeat(10 - n) + String.format(Locale.US, " %.0fdB", db)
    }

    // ================= Capture =================

    private fun stamp() =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/APlusCam")
        }
        val meta = ImageCapture.Metadata().apply {
            isReversedHorizontal = lens == CameraSelector.LENS_FACING_FRONT
        }
        val opts = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
        ).setMetadata(meta).build()

        b.shutter.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).withEndAction {
            b.shutter.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()

        ic.takePicture(opts, main, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                lastUri = r.savedUri
                Toast.makeText(this@MainActivity, "اتحفظت ✔", Toast.LENGTH_SHORT).show()
            }
            override fun onError(e: ImageCaptureException) {
                Toast.makeText(this@MainActivity, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun toggleRecording() {
        val vc = videoCapture ?: return
        recording?.let {
            it.stop()
            return
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME,
                "${'A' + camIdIdx}${String.format(Locale.US, "%03d", clipNo)}_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/APlusCam")
        }
        val out = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(cv).build()

        var pending = vc.output.prepareRecording(this, out)
        if (audioOn && granted(Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled()

        recording = pending.start(main) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    setRecordingUi(true)
                    clipNo++
                    prefs.edit().putInt("clip", clipNo).apply()
                }
                is VideoRecordEvent.Status -> {
                    val sec = ev.recordingStats.recordedDurationNanos / 1_000_000_000L
                    val meter = if (audioOn) "   🎤 " + meterBar(ev.recordingStats.audioStats.audioAmplitude) else ""
                    b.info.setTextColor(red)
                    b.info.text = String.format(Locale.US, "● REC %02d:%02d", sec / 60, sec % 60) + meter
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    if (!ev.hasError()) lastUri = ev.outputResults.outputUri
                    setRecordingUi(false)
                    val msg = if (ev.hasError()) "خطأ في الفيديو" else "الفيديو اتحفظ ✔"
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
                else -> {}
            }
        }
    }

    private fun setRecordingUi(on: Boolean) {
        b.shutter.setBackgroundResource(if (on) R.drawable.shutter_stop else R.drawable.shutter_rec)
        if (!on) { b.info.setTextColor(0xFFFFFFFF.toInt()); b.info.text = hudText() }
    }
}
